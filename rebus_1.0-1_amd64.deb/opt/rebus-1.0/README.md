﻿Předběžný plán projektu - Tým Rébus

Komunikační prostředky:
Jako komunikační kanál jsme zvolili Messenger na Facebooku, protože ho všichni využíváme a mimo spánek jsme online prakticky neustále. Máme založenou skupinovou konverzaci a taktéž jsme založili tajnou skupinu, kam budeme vkládat důležité informace pro všechny členy týmu.

Systém pro správu verzí:
Jako verzovací nástroj budeme používat Git. Společným místem pro náš kód jsme zvolili pro nás všechny známou službu GitHub.

Přidělení úkolu na projektu:
Matematické funkce - Tomáš Blažek/Kohout
GUI - Marek Schauer
Testy - Tomáš Blažek/Kohout

Termíny:
Dokončení návrhu do 1. dubna. 
Do 10. dubna chceme mít hotovou funkční matematickou knihovnu.
V týdnu od 10. do 17. dubna vytvoříme uživatelské grafické rozhraní.
Finální testování od 17. do 20. dubna.
Plánovaný termín dokončení: 20.dubna.
Odevzdání: 24. dubna 2017.
