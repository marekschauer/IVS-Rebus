#/bin/bash
. ~/.nvm/nvm.sh
nvm install 5.0
nvm use 5.0
